import { IMenuItem } from "./IMenuItem";

export interface IMenu {
    menuItems: IMenuItem[];
}